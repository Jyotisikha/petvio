package com.example.petvio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
