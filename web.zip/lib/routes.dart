class Routes {
  static String homePage = "/home";
  static String loginPage = "/login";
  
}
